<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Mi_ERP_HRM_Ajax {
    public function __construct() {
        add_action( 'wp_ajax_mi_erp_load_hrm', array( $this, 'load_hrm_data' ) );
        add_action( 'wp_ajax_mi_erp_load_salary_settings', array( $this, 'load_salary_settings' ) );
        add_action( 'wp_ajax_mi_erp_save_salary_settings', array( $this, 'save_salary_settings' ) );
    }

    private function check_permission() {
        check_ajax_referer( 'mi_erp_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permission denied' );
        }
    }

    public function load_hrm_data() {
        $this->check_permission();
        global $wpdb;

        $period = isset( $_POST['period'] ) ? sanitize_text_field( wp_unslash( $_POST['period'] ) ) : date('Y-m');
        
        // Tự động đồng bộ và tính toán lại KPI cho kỳ này trước khi load
        $this->sync_metrics( $period );
        
        $table_metrics = $wpdb->prefix . 'mi_employee_metrics';
        $metrics = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_metrics WHERE period = %s", $period ) );
        
        // Ensure all users who are authors/shop managers have a record
        $users = get_users( array( 'role__in' => array( 'administrator', 'shop_manager', 'author', 'editor' ) ) );
        
        $formatted_users = array();
        foreach ( $users as $u ) {
            $user_id = $u->ID;
            $m = null;
            foreach ( $metrics as $metric ) {
                if ( $metric->user_id == $user_id ) {
                    $m = $metric;
                    break;
                }
            }

            if ( ! $m ) {
                $m = (object) array(
                    'total_sales_amount' => 0,
                    'total_commissions' => 0
                );
            }

            $base_salary = get_user_meta( $user_id, '_mi_erp_base_salary', true );
            $base_salary = $base_salary !== '' ? floatval( $base_salary ) : 0;
            
            $total_income = $base_salary + floatval($m->total_commissions);

            $formatted_users[] = array(
                'id' => $user_id,
                'name' => $u->display_name,
                'email' => $u->user_email,
                'sales' => wc_price( $m->total_sales_amount ),
                'base_salary' => wc_price( $base_salary ),
                'commissions' => wc_price( $m->total_commissions ),
                'total_income' => wc_price( $total_income )
            );
        }

        wp_send_json_success( array(
            'period' => $period,
            'users' => $formatted_users
        ) );
    }

    private function sync_metrics( $period ) {
        global $wpdb;
        $table_metrics = $wpdb->prefix . 'mi_employee_metrics';
        $ticket_table = $wpdb->prefix . 'mi_tickets';

        // Tính khoảng thời gian của kỳ (VD: 2023-10-01 đến 2023-10-31)
        $start_date = $period . '-01';
        $end_date = date('Y-m-t', strtotime($start_date));

        // 1. Lấy Doanh số từ WooCommerce bằng wc_get_orders (Tương thích HPOS)
        $args = array(
            'status'       => array( 'completed', 'processing' ),
            'date_created' => $start_date . '...' . $end_date,
            'limit'        => -1, // Lấy tất cả
            'return'       => 'objects',
        );

        $orders = wc_get_orders( $args );

        $user_sales = array();
        foreach ( $orders as $order ) {
            $emp_id = $order->get_meta( '_mi_erp_sales_employee' );
            if ( ! empty( $emp_id ) ) {
                $uid = intval( $emp_id );
                if ( ! isset( $user_sales[$uid] ) ) {
                    $user_sales[$uid] = 0;
                }
                $user_sales[$uid] += floatval( $order->get_total() );
            }
        }

        // 2. Lấy số lượng Ticket đã giải quyết từ phân hệ CRM
        $start_datetime = $start_date . ' 00:00:00';
        $end_datetime = $end_date . ' 23:59:59';
        
        $tickets = $wpdb->get_results( $wpdb->prepare( "
            SELECT assigned_to, COUNT(id) as resolved_count
            FROM $ticket_table
            WHERE status IN ('resolved', 'closed')
            AND created_at >= %s AND created_at <= %s
            GROUP BY assigned_to
        ", $start_datetime, $end_datetime ) );

        $user_tickets = array();
        foreach ( $tickets as $t ) {
            $user_tickets[intval($t->assigned_to)] = intval($t->resolved_count);
        }

        // 3. Tính lương/thưởng cho từng nhân sự
        $users = get_users( array( 'role__in' => array( 'administrator', 'shop_manager', 'author', 'editor' ) ) );
        
        foreach ( $users as $u ) {
            $uid = $u->ID;
            $sales = isset($user_sales[$uid]) ? $user_sales[$uid] : 0;
            $ticket_count = isset($user_tickets[$uid]) ? $user_tickets[$uid] : 0;
            
            // Lấy cấu hình lương/thưởng từ User Meta
            $commission_rate = get_user_meta( $uid, '_mi_erp_commission_rate', true );
            $commission_rate = $commission_rate !== '' ? (floatval($commission_rate) / 100) : 0; // Mặc định 0% nếu không cài

            $ticket_bonus = get_user_meta( $uid, '_mi_erp_ticket_bonus', true );
            $ticket_bonus = $ticket_bonus !== '' ? floatval($ticket_bonus) : 0; // Mặc định 0đ nếu không cài
            
            // Tính hoa hồng
            $commission = ($sales * $commission_rate) + ($ticket_count * $ticket_bonus);

            // Cập nhật vào DB
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table_metrics WHERE user_id = %d AND period = %s", $uid, $period ) );
            if ( $exists ) {
                $wpdb->update( $table_metrics, array(
                    'total_sales_amount' => $sales,
                    'total_commissions'  => $commission
                ), array( 'id' => $exists ), array( '%f', '%f' ), array( '%d' ) );
            } else {
                $wpdb->insert( $table_metrics, array(
                    'user_id'            => $uid,
                    'period'             => $period,
                    'total_sales_amount' => $sales,
                    'total_commissions'  => $commission
                ), array( '%d', '%s', '%f', '%f' ) );
            }
        }
    }

    public function load_salary_settings() {
        $this->check_permission();
        
        $users = get_users( array( 'role__in' => array( 'administrator', 'shop_manager', 'author', 'editor' ) ) );
        $formatted_users = array();
        
        foreach ( $users as $u ) {
            $base_salary = get_user_meta( $u->ID, '_mi_erp_base_salary', true );
            $commission_rate = get_user_meta( $u->ID, '_mi_erp_commission_rate', true );
            $ticket_bonus = get_user_meta( $u->ID, '_mi_erp_ticket_bonus', true );
            $department = get_user_meta( $u->ID, '_mi_erp_department', true );

            $formatted_users[] = array(
                'id'              => $u->ID,
                'name'            => $u->display_name,
                'department'      => $department !== '' ? $department : 'Chưa phân bổ',
                'base_salary'     => $base_salary !== '' ? floatval($base_salary) : 0,
                'commission_rate' => $commission_rate !== '' ? floatval($commission_rate) : 0,
                'ticket_bonus'    => $ticket_bonus !== '' ? floatval($ticket_bonus) : 0
            );
        }
        
        wp_send_json_success( $formatted_users );
    }

    public function save_salary_settings() {
        $this->check_permission();
        
        if ( ! isset( $_POST['settings'] ) || ! is_array( $_POST['settings'] ) ) {
            wp_send_json_error( 'Dữ liệu không hợp lệ.' );
        }
        
        foreach ( $_POST['settings'] as $setting ) {
            $user_id = intval( $setting['user_id'] );
            if ( $user_id <= 0 ) continue;
            
            update_user_meta( $user_id, '_mi_erp_department', sanitize_text_field( $setting['department'] ) );
            update_user_meta( $user_id, '_mi_erp_base_salary', floatval( $setting['base_salary'] ) );
            update_user_meta( $user_id, '_mi_erp_commission_rate', floatval( $setting['commission_rate'] ) );
            update_user_meta( $user_id, '_mi_erp_ticket_bonus', floatval( $setting['ticket_bonus'] ) );
        }
        
        wp_send_json_success( 'Đã lưu cấu hình lương thành công.' );
    }
}
new Mi_ERP_HRM_Ajax();
