<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap">
    <h1 class="wp-heading-inline text-2xl font-bold mb-4">Quản lý Nhân sự & Lương thưởng (HRM)</h1>
    <hr class="wp-header-end">
    
    <div class="mt-4 flex border-b border-gray-200">
        <button class="tab-link px-6 py-3 font-semibold text-blue-700 bg-white border-l border-t border-r rounded-t" data-tab="tab-kpi">Hiệu suất & Lương (KPIs)</button>
        <button class="tab-link px-6 py-3 font-semibold text-gray-500 bg-gray-50 hover:bg-gray-100" data-tab="tab-settings">Cài đặt Cơ chế Lương</button>
    </div>

    <!-- TAB 1: KPI & LƯƠNG -->
    <div id="tab-kpi" class="tab-content bg-white p-6 rounded-b-lg shadow-sm border-l border-r border-b border-gray-200">
        <div class="flex flex-col sm:flex-row justify-between items-center border-b pb-4 mb-4 gap-4">
            <h2 class="text-lg font-bold text-gray-800">Hiệu suất nhân viên (Tháng này)</h2>
            <div class="flex gap-2 items-center">
                <label class="text-sm font-bold text-gray-700">Kỳ đánh giá:</label>
                <input type="month" id="hrm-period" class="shadow-sm border border-gray-300 rounded py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500" value="<?php echo date('Y-m'); ?>">
                <button type="button" id="btn-load-hrm" class="px-4 py-2 bg-blue-600 text-white rounded shadow-sm hover:bg-blue-700 font-bold text-sm transition-colors">Đồng bộ & Xem</button>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse" id="hrm-table">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="p-3 font-semibold text-sm text-gray-700">ID</th>
                        <th class="p-3 font-semibold text-sm text-gray-700">Nhân viên</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 text-right">Doanh thu bán</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 text-right">Lương cơ bản</th>
                        <th class="p-3 font-semibold text-sm text-green-700 text-right">Hoa hồng (Commission)</th>
                        <th class="p-3 font-semibold text-sm text-red-600 text-right">Tổng thu nhập</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <tr><td colspan="6" class="p-8 text-center text-gray-400 italic">Đang tải dữ liệu...</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 2: CÀI ĐẶT CƠ CHẾ LƯƠNG -->
    <div id="tab-settings" class="tab-content hidden bg-white p-6 rounded-b-lg shadow-sm border-l border-r border-b border-gray-200">
        <div class="flex justify-between items-center border-b pb-4 mb-4">
            <h2 class="text-lg font-bold text-gray-800">Cấu hình Lương, Thưởng & Phòng ban</h2>
            <button type="button" id="btn-save-settings" class="px-4 py-2 bg-green-600 text-white rounded shadow-sm hover:bg-green-700 font-bold text-sm transition-colors flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                Lưu cấu hình
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse" id="settings-table">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="p-3 font-semibold text-sm text-gray-700 w-1/12">ID</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 w-2/12">Nhân viên</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 w-2/12">Phòng ban</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 w-2/12">Lương cơ bản (₫)</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 w-2/12">% Hoa hồng DT</th>
                        <th class="p-3 font-semibold text-sm text-gray-700 w-3/12">Thưởng cố định / Đơn (₫)</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <tr><td colspan="6" class="p-8 text-center text-gray-400 italic">Đang tải dữ liệu...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Xử lý Tabs
    $('.tab-link').click(function() {
        $('.tab-link').removeClass('border-l border-t border-r rounded-t text-blue-700 bg-white').addClass('text-gray-500 bg-gray-50 hover:bg-gray-100 border-transparent');
        $(this).removeClass('text-gray-500 bg-gray-50 hover:bg-gray-100 border-transparent').addClass('border-l border-t border-r rounded-t text-blue-700 bg-white border-gray-200');
        
        $('.tab-content').addClass('hidden');
        let target = $(this).data('tab');
        $('#' + target).removeClass('hidden');

        if(target === 'tab-kpi') {
            loadHRMData();
        } else if (target === 'tab-settings') {
            loadSalarySettings();
        }
    });

    // Hàm format tiền (nếu cần ở JS)
    function formatCurrency(number) {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(number);
    }

    // Load KPI
    function loadHRMData() {
        let period = $('#hrm-period').val();
        if (!period) return;
        
        $('#hrm-table tbody').html('<tr><td colspan="6" class="p-8 text-center text-gray-400 italic">Đang tải và đồng bộ dữ liệu...</td></tr>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mi_erp_load_hrm',
                nonce: '<?php echo wp_create_nonce("mi_erp_admin_nonce"); ?>',
                period: period
            },
            success: function(res) {
                if (res.success) {
                    let users = res.data.users;
                    let html = '';
                    if (users.length === 0) {
                        html = '<tr><td colspan="6" class="p-8 text-center text-gray-400 italic">Chưa có nhân viên nào.</td></tr>';
                    } else {
                        users.forEach(function(u) {
                            html += `<tr class="hover:bg-gray-50 transition-colors">
                                <td class="p-3 font-bold text-sm text-gray-600">#${u.id}</td>
                                <td class="p-3">
                                    <div class="text-sm font-semibold text-gray-800">${u.name}</div>
                                    <div class="text-xs text-gray-500">${u.email}</div>
                                </td>
                                <td class="p-3 text-sm font-bold text-blue-600 text-right">${u.sales}</td>
                                <td class="p-3 text-sm font-medium text-gray-700 text-right">${u.base_salary}</td>
                                <td class="p-3 text-sm font-bold text-green-600 text-right">${u.commissions}</td>
                                <td class="p-3 text-base font-black text-red-600 text-right">${u.total_income}</td>
                            </tr>`;
                        });
                    }
                    $('#hrm-table tbody').html(html);
                } else {
                    $('#hrm-table tbody').html('<tr><td colspan="6" class="p-3 text-center text-red-500">Có lỗi xảy ra.</td></tr>');
                }
            }
        });
    }

    $('#btn-load-hrm').click(function() {
        $(this).text('Đang đồng bộ...').prop('disabled', true);
        let btn = $(this);
        setTimeout(function(){ btn.text('Đồng bộ & Xem').prop('disabled', false); }, 1500); // UI feel
        loadHRMData();
    });

    // Load Cài đặt Lương
    function loadSalarySettings() {
        $('#settings-table tbody').html('<tr><td colspan="6" class="p-8 text-center text-gray-400 italic">Đang tải dữ liệu...</td></tr>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mi_erp_load_salary_settings',
                nonce: '<?php echo wp_create_nonce("mi_erp_admin_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    let users = res.data;
                    let html = '';
                    if (users.length === 0) {
                        html = '<tr><td colspan="6" class="p-8 text-center text-gray-400 italic">Chưa có nhân viên nào.</td></tr>';
                    } else {
                        users.forEach(function(u) {
                            html += `<tr class="hover:bg-gray-50 transition-colors settings-row" data-user-id="${u.id}">
                                <td class="p-3 font-bold text-sm text-gray-600">#${u.id}</td>
                                <td class="p-3 text-sm font-semibold text-gray-800">${u.name}</td>
                                <td class="p-3">
                                    <input type="text" class="setting-dept shadow-sm border border-gray-300 rounded py-1 px-2 text-sm w-full focus:ring-1 focus:ring-blue-500" value="${u.department}">
                                </td>
                                <td class="p-3">
                                    <input type="number" class="setting-base shadow-sm border border-gray-300 rounded py-1 px-2 text-sm w-full focus:ring-1 focus:ring-blue-500" value="${u.base_salary}" min="0" step="100000">
                                </td>
                                <td class="p-3">
                                    <input type="number" class="setting-comm shadow-sm border border-gray-300 rounded py-1 px-2 text-sm w-full focus:ring-1 focus:ring-blue-500" value="${u.commission_rate}" min="0" max="100" step="0.1">
                                </td>
                                <td class="p-3">
                                    <input type="number" class="setting-bonus shadow-sm border border-gray-300 rounded py-1 px-2 text-sm w-full focus:ring-1 focus:ring-blue-500" value="${u.ticket_bonus}" min="0" step="10000">
                                </td>
                            </tr>`;
                        });
                    }
                    $('#settings-table tbody').html(html);
                }
            }
        });
    }

    // Save Cài đặt Lương
    $('#btn-save-settings').click(function() {
        let btn = $(this);
        let originalText = btn.html();
        btn.html('<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg> Đang lưu...').prop('disabled', true);
        
        let settingsData = [];
        $('.settings-row').each(function() {
            settingsData.push({
                user_id: $(this).data('user-id'),
                department: $(this).find('.setting-dept').val(),
                base_salary: $(this).find('.setting-base').val(),
                commission_rate: $(this).find('.setting-comm').val(),
                ticket_bonus: $(this).find('.setting-bonus').val()
            });
        });

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mi_erp_save_salary_settings',
                nonce: '<?php echo wp_create_nonce("mi_erp_admin_nonce"); ?>',
                settings: settingsData
            },
            success: function(res) {
                if (res.success) {
                    alert(res.data);
                } else {
                    alert('Lỗi: ' + res.data);
                }
            },
            complete: function() {
                btn.html(originalText).prop('disabled', false);
            }
        });
    });

    // Init
    loadHRMData();
});
</script>
